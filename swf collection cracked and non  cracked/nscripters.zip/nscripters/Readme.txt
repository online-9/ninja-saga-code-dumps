
 README

Hello there,
The only script you will need to edit for your needs its inside NScripters.php file.
Inside that file you also will see a description for how to use the script.
Please read that before doing anything.

In order to be able to use the script , you also need to have a little knowledge about php programming , if you dont i suggest you go learn that first.
If you have any problem using the script please feel free to contact me http://facebook.com/FlashNScripters

Flash NScripters